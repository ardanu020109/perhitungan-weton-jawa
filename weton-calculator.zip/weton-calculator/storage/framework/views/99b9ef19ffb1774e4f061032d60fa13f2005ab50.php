<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Weton</title>
</head>
<body>
    <h1>Hasil Perhitungan Weton</h1>
    <h2>Tanggal Lahir 1: <?php echo e($weton1['tanggal']); ?></h2>
    <p>Hari: <?php echo e($weton1['hari']); ?></p>
    <p>Pasaran: <?php echo e($weton1['pasaran']); ?></p>
    <p>Neptu: <?php echo e($weton1['neptu']); ?></p>

    <h2>Tanggal Lahir 2: <?php echo e($weton2['tanggal']); ?></h2>
    <p>Hari: <?php echo e($weton2['hari']); ?></p>
    <p>Pasaran: <?php echo e($weton2['pasaran']); ?></p>
    <p>Neptu: <?php echo e($weton2['neptu']); ?></p>

    <h2>Jumlah weton bersama pasangan anda adalah <?php echo e($jumlah_weton); ?>, maka kategori kalian berdua adalah <?php echo e($result); ?></h2>
    <a href="<?php echo e(route('weton.index')); ?>">Hitung Lagi</a>
</body>
</html>
<?php /**PATH C:\Users\Ardanu\Pictures\Hitung-Weton\weton-calculator\resources\views/weton/result.blade.php ENDPATH**/ ?>